/*  Override io.h for use in tcc4tcl 
    functions to override:
    lseek
    open
    close
    read
    
    Tcl IO Functions work on Tcl_Channel, io.h operate on int handles, 
    so we additionally need a mapping//hashtable to translate from one to the other
    
    in tcc.c beneath include tcctools.c
    #include "tcl_iomap.c"
*/    

#ifndef USE_TCL_STUBS
#define USE_TCL_STUBS 1
#endif
#ifndef _TCL
#include <tcl.h>
#endif

#ifndef _TCLIOMAP_
#define _TCLIOMAP_

#define open t_open
#define fdopen t_fdopen
#define fclose t_fclose
#define read t_read
#define lseek t_lseek
#define close t_close
#define fgets t_fgets
#define dup t_dup

#define MAXCHAN 128
Tcl_Channel _tcl_channels[MAXCHAN];
static int _chan_cnt =0;
static int lastchan=0;
void _initchantable () {
    _tcl_channels[0]=NULL;
    _chan_cnt=0;
}

int _chan2int (Tcl_Channel chan) {
    // insert channel to array, incr cnt, return cnt
    // start with 1, not 0
    
    if(chan==NULL) return -1;
    _chan_cnt++;
    if (_chan_cnt>MAXCHAN) {
        // out of channels
        return -1;
    }
    _tcl_channels[_chan_cnt]=chan;
    return _chan_cnt;    
}

Tcl_Channel _int2chan (int fd) {
    // get channel from array by int
    // start with 1 not 0
    Tcl_Channel chan;
    if (fd>_chan_cnt) return NULL;
    chan= _tcl_channels[fd];
    return chan;
}

int t_dup (int fd) {
    //
    return fd;
}

#define str_append(buf,str) pstrcat(buf, sizeof(buf),str);
int t_open(const char *_Filename,int _OpenFlag,...) {
    Tcl_Channel chan;
    Tcl_Obj *path;
    char buf[1024], src[500];
    buf[0] = '\0';
    char* rdmode="RDONLY";
    // interpret openflags to tcl
    int flagMask = 1 << 15; // start with high-order bit...
    while( flagMask != 0 )   // loop terminates once all flags have been compared
    {
      // switch on only a single bit...
      switch( _OpenFlag & flagMask )
      {
       //case O_RDONLY:
       //  str_append(buf,"RDONLY ");
       //  break;
       case O_WRONLY:
         rdmode="WRONLY";
         break;
       case O_RDWR:
         rdmode="RDWR";
         break;
       case O_APPEND:
         rdmode="APEND";
         break;
       case O_CREAT:
         rdmode="CREAT";
         break;
       case O_TRUNC:
         str_append(buf,"TRUNC ");
         break;
       case O_EXCL:
         str_append(buf,"EXCL ");
         break;
       case O_BINARY:
         str_append(buf,"BINARY ");
         break;
      }
      flagMask >>= 1;  // bit-shift the flag value one bit to the right
    }    
    str_append(buf,rdmode);
    //tcc_warning("open %s %s",_Filename,buf);
    if (strcmp(_Filename, "-") == 0) {
        chan = Tcl_GetStdChannel(TCL_STDIN);
        _Filename = "stdin";
    } else {
        path = Tcl_NewStringObj(_Filename,-1);
        Tcl_IncrRefCount(path);
        chan = Tcl_FSOpenFileChannel(NULL,path, buf, 0);
        Tcl_DecrRefCount(path);
    }    
    return _chan2int(chan);
}

char * t_fgets(char *_Buf,int _MaxCount,FILE *_File) {
    //
    if(_File==NULL) {
        // tcl mode
        if(lastchan==0) {
            return NULL;
        }
        Tcl_Channel chan=_int2chan(lastchan);
        
int n;
    for (n = 0; n < _MaxCount - 1; )
        if (Tcl_Read(chan, _Buf + n, 1) < 1 || _Buf[n++] == '\n')
            break;
    if (0 == n)
        return NULL;
        _Buf[n]='\0';
        return _Buf;
    }
    return NULL;
}

FILE *t_fdopen(int fd, const char *mode) {
    //
    Tcl_Channel chan;
    int tcl_ret;
    int native_fd;
    FILE* f;
    chan=_int2chan(fd);
    tcl_ret = Tcl_GetChannelHandle(chan, TCL_READABLE, (void*)&native_fd);
    if (tcl_ret != TCL_OK) {
       lastchan=fd;
	   return NULL;
    }

    #undef fdopen
    f = fdopen(native_fd, mode);
    #define fdopen t_fdopen
    if (!f) {
        lastchan=fd;
        return NULL;
    }
    return f;
}

int t_read(int _FileHandle,void *_DstBuf,unsigned int _MaxCharCount) {
    //
    Tcl_Channel chan;
    chan=_int2chan(_FileHandle);
    return Tcl_Read(chan, (char * )_DstBuf, _MaxCharCount);

}

int t_close(int _FileHandle) {
    //
    Tcl_Channel chan;
    chan=_int2chan(_FileHandle);
    _tcl_channels[_FileHandle]=NULL;
   
    while (_tcl_channels[_chan_cnt]==NULL) {
        _chan_cnt+=-1;
        if(_chan_cnt<2) break;
    }
    if(chan==NULL) return 0;
    return Tcl_Close(NULL,chan);
}

int t_fclose(FILE* fp) {
    if(fp!=NULL) {
        #undef fclose
        return fclose(fp);
        #define fclose t_fclose
    }
    if(lastchan!=0) {
        Tcl_Channel chan=_int2chan(lastchan);
        t_close(lastchan);
        lastchan=0;
    }
    return 1;
}

long t_lseek(int _FileHandle,long _Offset,int _Origin) {
    //
    Tcl_Channel chan;
    chan=_int2chan(_FileHandle);
    return Tcl_Seek(chan, _Offset, _Origin);
}

static char *get_line(char *line, int size, int fd)
{
    int n;
    for (n = 0; n < size - 1; )
        if (t_read(fd, line + n, 1) < 1 || line[n++] == '\n')
            break;
    if (0 == n)
        return NULL;
   return line;
}


int test_fio_01 (const char* fname,const char* text) {
    FILE* f;
    f = fopen(fname, "a");
    fprintf(f, "fname  \"%s\"   ", fname);
    fprintf(f, "text  \"%s\"\n", text);
    fclose(f);
    return 1;
}
    


#endif
