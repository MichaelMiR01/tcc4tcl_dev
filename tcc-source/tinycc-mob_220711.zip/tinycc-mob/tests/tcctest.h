static inline const char *get_basefile_from_header(void)
{
  return __BASE_FILE__;
}

static inline const char *get_file_from_header(void)
{
  return __FILE__;
}
