#define TCC_VERSION "0.9.27"
#ifdef TCC_TARGET_X86_64
#define TCC_LIBTCC1 "libtcc1-64.a"
#else
#define TCC_LIBTCC1 "libtcc1-32.a"
#endif
#ifdef _WIN32
#define CONFIG_WIN32 1
#define TCC_TARGET_PE 1
#endif
#define HOST_I386 1
#ifndef TCC_TARGET_X86_64
#define TCC_TARGET_I386 1
#endif
#ifdef _WIN32
#define _USE_32BIT_TIME_T 1
#include <stdint.h>
typedef __int64 __time64_t;
#endif
#define CONFIG_TCC_SYSINCLUDEPATHS "{B}/include;{B}/include/winapi;{B}/win32;{B}/win32/winapi"
