/*  Override io.h for use in tcc4tcl 
    functions to override:
    lseek
    open
    close
    read
    
    Tcl IO Functions work on Tcl_Channel, io.h operate on int handles, 
    so we additionally need a mapping//hashtable to translate from one to the other
    
*/    

#ifndef _TCL
#include <tcl.h>
#endif

#ifndef _TCLIOMAP_
#define _TCLIOMAP_


Tcl_Channel _tcl_channels[1024];
static int _chan_cnt =0;

void _initchantable () {
    _tcl_channels[0]=NULL;
    _chan_cnt=0;
}

int _chan2int (Tcl_Channel chan) {
    // insert channel to array, incr cnt, return cnt
    // start with 1, not 0
    _chan_cnt++;
    _tcl_channels[_chan_cnt]=chan;
    return _chan_cnt;    
}

Tcl_Channel _int2chan (int fd) {
    // get channel from array by int
    // start with 1 not 0
    Tcl_Channel chan;
    if (fd>_chan_cnt) return NULL;
    chan= _tcl_channels[fd];
    return chan;
}




int t_open(const char *_Filename,int _OpenFlag,...) {
    Tcl_Channel chan;
    Tcl_Obj *path;
    char buf[64];
    // interpret openflags to tcl
    int flagMask = 1 << 31; // start with high-order bit...
    while( flagMask != 0 )   // loop terminates once all flags have been compared
    {
      // switch on only a single bit...
      switch( _OpenFlag & flagMask )
      {
       case O_RDONLY:
         sprintf(buf,"%s RDONLY",buf);
         break;
       case O_WRONLY:
         sprintf(buf,"%s WRONLY",buf);
         break;
       case O_RDWR:
         sprintf(buf,"%s RDWR",buf);
         break;
       case O_APPEND:
         sprintf(buf,"%s APPEND",buf);
         break;
       case O_CREAT:
         sprintf(buf,"%s CREAT",buf);
         break;
       case O_TRUNC:
         sprintf(buf,"%s TRUNC",buf);
         break;
       case O_EXCL:
         sprintf(buf,"%s EXCL",buf);
         break;
       case O_BINARY:
         sprintf(buf,"%s BINARY",buf);
         break;
    
      }
      flagMask >>= 1;  // bit-shift the flag value one bit to the right
    }    
    
    if (strcmp(_Filename, "-") == 0) {
        chan = Tcl_GetStdChannel(TCL_STDIN);
        _Filename = "stdin";
    } else {
        path = Tcl_NewStringObj(_Filename,-1);
        Tcl_IncrRefCount(path);
        chan = Tcl_FSOpenFileChannel(NULL,path, buf, 0);
        Tcl_DecrRefCount(path);
    }    
    return _chan2int(chan);
}

int t_read(int _FileHandle,void *_DstBuf,unsigned int _MaxCharCount) {
    //
    Tcl_Channel chan;
    chan=_int2chan(_FileHandle);
    return Tcl_Read(chan, (char * )_DstBuf, _MaxCharCount);

}

int t_close(int _FileHandle) {
    //
    Tcl_Channel chan;
    chan=_int2chan(_FileHandle);
    return Tcl_Close(NULL,chan);
}

long t_lseek(int _FileHandle,long _Offset,int _Origin) {
    //
    Tcl_Channel chan;
    chan=_int2chan(_FileHandle);
    return Tcl_Seek(chan, _Offset, _Origin);
}


#endif
