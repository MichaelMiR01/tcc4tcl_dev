
#ifdef put_stabs
#undef put_stabs
static void put_stabs(TCCState *s1, const char *str, int type, int other, int desc, unsigned long value);
#define puts_stabs t_put_stabs


void t_put_stabs(TCCState *s1, const char *str, int type, int other, int desc, unsigned long value) {
    if (s1->ppfp && s1->ppfp != stdout &&str) {
        fprintf(s1->ppfp, "Sym:%s|type:%d\n", str, type); 
    }
    #undef put_stabs
        put_stabs(s1, str,  type,  other,  desc, value);
    #define puts_stabs t_put_stabs
}

#endif // put_stabs
